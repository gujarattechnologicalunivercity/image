
import { cn } from "@/lib/utils";

export const LoadingSpinner = ({ className }: { className?: string }) => {
  return (
    <div className={cn("flex items-center justify-center", className)}>
      <div className="relative w-12 h-12">
        <div className="absolute inset-0 rounded-full border-4 border-gray-200 opacity-25"></div>
        <div className="absolute inset-0 rounded-full border-4 border-t-primary animate-spin-slow"></div>
      </div>
    </div>
  );
};
